cur_dir=$PWD
result_dir='/home/yuan/Dropbox/2plate_shell_veri/results'
cd $cur_dir

# for LAYER in 2layer  ;
# # for LAYER in 1layer 2layer 4layer  ;
# do
# # for FILE in side_length_0quarter \
# for FILE in side_length_0quarter \
#             side_length_0half \
# 			side_length_01 \
# 			side_length_02 \
# 			side_length_05 \
# 			side_length_10 ;
# do
# cd ${cur_dir}/${LAYER}/${FILE}/fei
essi_max_disp 0_bending_and_shear.h5.feioutput > $cur_dir/00result_b_shear.txt
essi_max_disp 1_bending_and_shear.h5.feioutput >> $cur_dir/00result_b_shear.txt
essi_max_disp 2_bending_and_shear.h5.feioutput >> $cur_dir/00result_b_shear.txt
essi_max_disp 3_bending_and_shear.h5.feioutput >> $cur_dir/00result_b_shear.txt
essi_max_disp 4_bending_and_shear.h5.feioutput >> $cur_dir/00result_b_shear.txt
essi_max_disp 5_bending_and_shear.h5.feioutput >> $cur_dir/00result_b_shear.txt
essi_max_disp 6_bending_and_shear.h5.feioutput >> $cur_dir/00result_b_shear.txt
essi_max_disp 7_bending_and_shear.h5.feioutput >> $cur_dir/00result_b_shear.txt
essi_max_disp 8_bending_and_shear.h5.feioutput >> $cur_dir/00result_b_shear.txt
essi_max_disp 9_bending_and_shear.h5.feioutput >> $cur_dir/00result_b_shear.txt
essi_max_disp 10_bending_and_shear.h5.feioutput >> $cur_dir/00result_b_shear.txt

essi_max_disp 0_bending_and_shear.h5.feioutput > $result_dir/beam_4div_andes4_b_shear.txt
essi_max_disp 1_bending_and_shear.h5.feioutput >> $result_dir/beam_4div_andes4_b_shear.txt
essi_max_disp 2_bending_and_shear.h5.feioutput >> $result_dir/beam_4div_andes4_b_shear.txt
essi_max_disp 3_bending_and_shear.h5.feioutput >> $result_dir/beam_4div_andes4_b_shear.txt
essi_max_disp 4_bending_and_shear.h5.feioutput >> $result_dir/beam_4div_andes4_b_shear.txt
essi_max_disp 5_bending_and_shear.h5.feioutput >> $result_dir/beam_4div_andes4_b_shear.txt
essi_max_disp 6_bending_and_shear.h5.feioutput >> $result_dir/beam_4div_andes4_b_shear.txt
essi_max_disp 7_bending_and_shear.h5.feioutput >> $result_dir/beam_4div_andes4_b_shear.txt
essi_max_disp 8_bending_and_shear.h5.feioutput >> $result_dir/beam_4div_andes4_b_shear.txt
essi_max_disp 9_bending_and_shear.h5.feioutput >> $result_dir/beam_4div_andes4_b_shear.txt
essi_max_disp 10_bending_and_shear.h5.feioutput >> $result_dir/beam_4div_andes4_b_shear.txt



essi_max_disp 0_pureBending.h5.feioutput > $cur_dir/00result_bending.txt
essi_max_disp 1_pureBending.h5.feioutput >> $cur_dir/00result_bending.txt
essi_max_disp 2_pureBending.h5.feioutput >> $cur_dir/00result_bending.txt
essi_max_disp 3_pureBending.h5.feioutput >> $cur_dir/00result_bending.txt
essi_max_disp 4_pureBending.h5.feioutput >> $cur_dir/00result_bending.txt
essi_max_disp 5_pureBending.h5.feioutput >> $cur_dir/00result_bending.txt
essi_max_disp 6_pureBending.h5.feioutput >> $cur_dir/00result_bending.txt
essi_max_disp 7_pureBending.h5.feioutput >> $cur_dir/00result_bending.txt
essi_max_disp 8_pureBending.h5.feioutput >> $cur_dir/00result_bending.txt
essi_max_disp 9_pureBending.h5.feioutput >> $cur_dir/00result_bending.txt
essi_max_disp 10_pureBending.h5.feioutput >> $cur_dir/00result_bending.txt

essi_max_disp 0_pureBending.h5.feioutput > $result_dir/beam_4div_andes4_bending.txt
essi_max_disp 1_pureBending.h5.feioutput >> $result_dir/beam_4div_andes4_bending.txt
essi_max_disp 2_pureBending.h5.feioutput >> $result_dir/beam_4div_andes4_bending.txt
essi_max_disp 3_pureBending.h5.feioutput >> $result_dir/beam_4div_andes4_bending.txt
essi_max_disp 4_pureBending.h5.feioutput >> $result_dir/beam_4div_andes4_bending.txt
essi_max_disp 5_pureBending.h5.feioutput >> $result_dir/beam_4div_andes4_bending.txt
essi_max_disp 6_pureBending.h5.feioutput >> $result_dir/beam_4div_andes4_bending.txt
essi_max_disp 7_pureBending.h5.feioutput >> $result_dir/beam_4div_andes4_bending.txt
essi_max_disp 8_pureBending.h5.feioutput >> $result_dir/beam_4div_andes4_bending.txt
essi_max_disp 9_pureBending.h5.feioutput >> $result_dir/beam_4div_andes4_bending.txt
essi_max_disp 10_pureBending.h5.feioutput >> $result_dir/beam_4div_andes4_bending.txt



# done
# done


