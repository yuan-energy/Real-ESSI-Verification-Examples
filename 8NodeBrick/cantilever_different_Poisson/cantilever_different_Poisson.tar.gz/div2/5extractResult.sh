cur_dir=$PWD
result_dir='/home/yuan/Dropbox/2plate_shell_veri/results'
cd $cur_dir

# for LAYER in 2layer  ;
# # for LAYER in 1layer 2layer 4layer  ;
# do
# # for FILE in side_length_0quarter \
# for FILE in side_length_0quarter \
#             side_length_0half \
# 			side_length_01 \
# 			side_length_02 \
# 			side_length_05 \
# 			side_length_10 ;
# do
# cd ${cur_dir}/${LAYER}/${FILE}/fei
essi_max_disp 0_Fz.h5.feioutput > $cur_dir/00result.txt
essi_max_disp 1_Fz.h5.feioutput >> $cur_dir/00result.txt
essi_max_disp 2_Fz.h5.feioutput >> $cur_dir/00result.txt
essi_max_disp 3_Fz.h5.feioutput >> $cur_dir/00result.txt
essi_max_disp 4_Fz.h5.feioutput >> $cur_dir/00result.txt
essi_max_disp 5_Fz.h5.feioutput >> $cur_dir/00result.txt
essi_max_disp 6_Fz.h5.feioutput >> $cur_dir/00result.txt
essi_max_disp 7_Fz.h5.feioutput >> $cur_dir/00result.txt
essi_max_disp 8_Fz.h5.feioutput >> $cur_dir/00result.txt
essi_max_disp 9_Fz.h5.feioutput >> $cur_dir/00result.txt
essi_max_disp 10_Fz.h5.feioutput >> $cur_dir/00result.txt

essi_max_disp 0_Fz.h5.feioutput > $result_dir/beam_2div_brick8.txt
essi_max_disp 1_Fz.h5.feioutput >> $result_dir/beam_2div_brick8.txt
essi_max_disp 2_Fz.h5.feioutput >> $result_dir/beam_2div_brick8.txt
essi_max_disp 3_Fz.h5.feioutput >> $result_dir/beam_2div_brick8.txt
essi_max_disp 4_Fz.h5.feioutput >> $result_dir/beam_2div_brick8.txt
essi_max_disp 5_Fz.h5.feioutput >> $result_dir/beam_2div_brick8.txt
essi_max_disp 6_Fz.h5.feioutput >> $result_dir/beam_2div_brick8.txt
essi_max_disp 7_Fz.h5.feioutput >> $result_dir/beam_2div_brick8.txt
essi_max_disp 8_Fz.h5.feioutput >> $result_dir/beam_2div_brick8.txt
essi_max_disp 9_Fz.h5.feioutput >> $result_dir/beam_2div_brick8.txt
essi_max_disp 10_Fz.h5.feioutput >> $result_dir/beam_2div_brick8.txt


# done
# done


